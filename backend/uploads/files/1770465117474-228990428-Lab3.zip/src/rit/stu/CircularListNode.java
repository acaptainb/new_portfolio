package rit.stu;

import rit.cs.CircularList;

public class CircularListNode<E> implements CircularList<E> {
    private static class Node<E> {
        E data;
        Node<E> next;
        Node<E> prev;

        Node(E data) {
            this.data = data;
            this.next = this;
            this.prev = this;
        }
    }

    // TODO - From problem solving.  Add the necessary private state to represent the head, cursor and size
    private Node<E> head;
    private Node<E> cursor;
    private int size;

    /**
     * Initialize the list to be empty.  This means the head and cursor are both null
     * and the size is 0.
     */
    public CircularListNode() {
        this.head = null;
        this.cursor = null;
        this.size = 0;
    }

    @Override
    public void append(E element) {
        // TODO

        Node<E> newNode = new Node<>(element);

        if (size == 0) {
            head = cursor = newNode;
        } else {
            Node<E> tail = head.prev;

            tail.next = newNode;
            newNode.prev = tail;
            newNode.next = head;
            head.prev = newNode;
        }
        size++;
    }

    @Override
    public int size() {
        // TODO
        return size;
    }

    @Override
    public boolean valid(){
        return cursor != null;
}

    @Override
    public void reset() {
        // TODO
        cursor = (head == null) ? null : head;
    }

    @Override
    public void forward() {
        // TODO
        assert cursor != null : "can't forward cursor, the list is empty!";
        cursor = cursor.next;
    }

    @Override
    public void backward() {
        //
        assert cursor != null : "can't backward cursor, the list is empty!";
        cursor = cursor.prev;
    }

    @Override
    public E get() {
        // TODO
        assert cursor != null : "can't get, cursor is off the list!";
        return cursor.data;
    }

    @Override
    public E removeForward() {
        // TODO
        assert cursor != null : "can't removeForward, cursor is off the list!";
        E removed = cursor.data;
        if (size == 1) {
            head = cursor = null;
        }
        else {
            Node nextNode = cursor.next;
            Node prevNode = cursor.prev;

            prevNode.next = nextNode;
            nextNode.prev = prevNode;
            if (cursor == head) {
                head = nextNode;
            }
            cursor = nextNode;
        }
        size--;
        return removed;
    }

    @Override
    public E removeBackward() {
        // TODO
        assert cursor != null : "can't removeBackward, cursor is off the list!";
        E removed = cursor.data;
        if (size == 1) {
            head = cursor = null;
        }
        else {
            Node nextNode = cursor.next;
            Node prevNode = cursor.prev;
            prevNode.next = nextNode;
            nextNode.prev = prevNode;
            if (cursor == head) {
                head = prevNode;
            }
            cursor = prevNode;
        }
        size--;
        return removed;

    }

    @Override
    public String toString() {
        // TODO:  Use System.lineSeparator() instead of "\n" when appending a newline!!!! done
        if (size == 0) {
            return "Empty list!";
        }
        String result = "";
        Node temp = head;



        for (int i = 0; i < size; i++) {
            result += temp.data;
            if (temp == cursor) {
                result += " <-- CURSOR";
            }




            result += System.lineSeparator();
            temp = temp.next;
        }
        return result;
    }
}
