package hotpotato;

public class Player {
    private final String name;
    private final int id;

    public Player(String name, int id){
        this.name = name;
        this.id = id;
    }

    public int getId(){
        return id;
    }

    public String getName(){
        return name;
    }
    @Override
    public boolean equals(Object other){
        if (other instanceof Player){
            Player player = (Player) other;
            return player.id==this.id && this.name.equals(player.name);
        }
            return false;
    }

    @Override
    public String toString(){
        return name + "(" +id+ ")";
    }




}
